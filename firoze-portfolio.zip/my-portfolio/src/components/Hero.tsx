"use client";

import { motion } from "framer-motion";
import { ArrowRight, ChevronDown, Download } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background">
      {/* Background abstract gradient */}
      <div className="absolute inset-0 z-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/10 via-background to-background"></div>
      
      <div className="container relative z-10 px-4 py-32 sm:px-6 lg:px-8 text-center sm:text-left">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-3xl"
        >
          <div className="inline-flex items-center rounded-full px-3 py-1 mb-6 text-sm font-semibold text-primary/80 ring-1 ring-inset ring-primary/20 bg-primary/5">
            M.Sc Logistics Systems Engineering @ BGSU
          </div>
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-foreground mb-6">
            Hi, I'm <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-400">Md Firoze Mehedi</span>
          </h1>
          <p className="mt-4 text-xl sm:text-2xl text-muted-foreground max-w-2xl mb-10 leading-relaxed">
            I specialize in Supply Chain Analytics, Demand Forecasting, and ML-driven automation for manufacturing systems.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center sm:justify-start">
            <a
              href="#contact"
              className="inline-flex items-center justify-center rounded-xl bg-primary px-6 py-3.5 text-base font-semibold text-primary-foreground shadow-sm hover:bg-primary/90 transition-all duration-200"
            >
              Get in Touch
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
            <a
              href="#"
              className="inline-flex items-center justify-center rounded-xl bg-secondary px-6 py-3.5 text-base font-semibold text-foreground shadow-sm hover:bg-secondary/80 outline-none ring-1 ring-border transition-all duration-200"
            >
              <Download className="mr-2 h-5 w-5" />
              Download Resume
            </a>
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center justify-center text-muted-foreground animate-bounce"
      >
        <span className="text-sm font-medium mb-2">Scroll Down</span>
        <ChevronDown className="h-5 w-5" />
      </motion.div>
    </section>
  );
}
