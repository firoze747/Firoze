"use client";

import { motion } from "framer-motion";

const experiences = [
  {
    role: "Graduate Research Assistant",
    company: "Bowling Green State University",
    location: "Ohio, USA",
    date: "Sep 2025 – Present",
    points: [
      "Research on AGV-assisted manufacturing, demand forecasting, and ML-driven automation; quantitative modeling, data analytics, and performance evaluation.",
      "Processed 2,000+ high-speed camera images per phase; image-based data analysis for mechanical system validation and reliability."
    ]
  },
  {
    role: "Jr Data Analyst",
    company: "The Analytics Team",
    location: "Dhaka, Bangladesh",
    date: "Sep 2022 – Apr 2023",
    points: [
      "Supported e-commerce and web analytics with Google Analytics; data collection, reporting, and insight generation for business and revenue analysis."
    ]
  },
  {
    role: "Digital Marketing Executive",
    company: "Coder Castle LLC",
    location: "Dhaka, Bangladesh",
    date: "Feb 2022 – Jun 2022",
    points: [
      "SEO, on-page optimization, and content planning to improve traffic and engagement."
    ]
  },
  {
    role: "Operations Associate – Manufacturing & Supply Chain",
    company: "Artificer",
    location: "Dhaka, Bangladesh",
    date: "Nov 2020 – Oct 2021",
    points: [
      "Shift from import sourcing to in-house manufacturing post-COVID; raw material sourcing, design coordination, cost control, and quality–price optimization."
    ]
  }
];

export default function Experience() {
  return (
    <section id="experience" className="py-24 bg-background">
      <div className="container px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Work Experience</h2>
          <div className="h-1 w-20 bg-primary/80 rounded-full"></div>
        </motion.div>

        <div className="space-y-12">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative pl-8 sm:pl-0"
            >
              <div className="flex flex-col sm:flex-row gap-4 sm:gap-8 cursor-default group">
                <div className="sm:w-1/4 pt-1 flex flex-col">
                  <span className="text-sm font-semibold text-primary/80 uppercase tracking-wider">{exp.date}</span>
                  <span className="text-xs text-muted-foreground mt-1 block">{exp.location}</span>
                </div>
                
                <div className="sm:w-3/4 relative pb-8 sm:pb-12 border-l-2 border-border pl-6 sm:pl-8 last:pb-0 last:border-transparent">
                  <div className="absolute w-4 h-4 rounded-full bg-background border-2 border-primary -left-[9px] top-1 group-hover:bg-primary transition-colors duration-300"></div>
                  <h3 className="text-xl font-bold text-foreground mb-1">{exp.role}</h3>
                  <h4 className="text-lg font-medium text-muted-foreground mb-4">{exp.company}</h4>
                  
                  <ul className="space-y-3">
                    {exp.points.map((point, i) => (
                      <li key={i} className="text-base text-muted-foreground flex items-start">
                        <span className="mr-2 mt-1.5 h-1.5 w-1.5 rounded-full bg-primary/50 flex-shrink-0"></span>
                        {point}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
