"use client";

import { motion } from "framer-motion";

const education = [
  {
    degree: "Master of Science in Logistics Systems Engineering",
    school: "Bowling Green State University (USA)",
    date: "Aug 2025 – May 2027"
  },
  {
    degree: "Master of Science in IT, Systems and Management",
    school: "Washington University of Science and Technology (USA)",
    date: "Jul 2023 – Jun 2025"
  },
  {
    degree: "Bachelor of Science in Computer Science & Engineering",
    school: "Daffodil International University (Bangladesh)",
    date: "May 2018 – Apr 2023"
  }
];

const projects = [
  {
    title: "Hybrid AI–Forecasting & Stochastic Optimization",
    school: "BGSU",
    date: "Nov 2025",
    description: "Hybrid ML + classical forecasting; stochastic optimization to minimize inventory costs under demand uncertainty (Walmart)."
  },
  {
    title: "AGV Adoption in Warehouse Operations",
    school: "BGSU",
    date: "Jan 2026",
    description: "Analyzed AGV impact on warehouse safety, order picking efficiency, and human-robot collaboration."
  },
  {
    title: "AI Influence on Sustainable Production",
    school: "BGSU",
    date: "Jan 2026",
    description: "Co-authored research on AI-driven sustainable manufacturing; supervised by Asst. Prof. Md Imran Hasan Tusar."
  },
  {
    title: "Healthcare Data Analytics Infrastructure",
    school: "WUST",
    date: "Jun 2025",
    description: "End-to-end cloud analytics (AWS, MongoDB, Apache Kafka) for secure healthcare data and operational efficiency."
  }
];

export default function EducationProjects() {
  return (
    <section id="education" className="py-24 bg-background">
      <div className="container px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto space-y-24">
        
        {/* Education Section */}
        <div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12"
          >
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Education</h2>
            <div className="h-1 w-20 bg-primary/80 rounded-full"></div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {education.map((edu, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="p-6 rounded-2xl bg-card border border-border/50 shadow-sm relative overflow-hidden group hover:border-primary/50 transition-colors"
              >
                <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-primary to-blue-500 transform origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-300"></div>
                <h3 className="text-lg font-bold mb-2 leading-tight">{edu.degree}</h3>
                <p className="text-muted-foreground font-medium mb-4">{edu.school}</p>
                <span className="inline-block px-3 py-1 bg-secondary/50 text-secondary-foreground text-xs font-semibold rounded-full mt-auto">
                  {edu.date}
                </span>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Projects Section */}
        <div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12"
          >
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Research & Projects</h2>
            <div className="h-1 w-20 bg-primary/80 rounded-full"></div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {projects.map((project, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="p-8 rounded-2xl bg-card border border-border/50 shadow-sm transition-shadow hover:shadow-md"
              >
                <div className="flex justify-between items-start mb-4 gap-4">
                  <h3 className="text-xl font-bold">{project.title}</h3>
                  <span className="whitespace-nowrap px-2.5 py-1 bg-primary/10 text-primary text-xs font-bold rounded-md">
                    {project.date}
                  </span>
                </div>
                <p className="text-muted-foreground mb-6 line-clamp-3">
                  {project.description}
                </p>
                <div className="text-sm font-semibold text-foreground bg-secondary/50 inline-block px-3 py-1.5 rounded-lg">
                  {project.school}
                </div>
              </motion.div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
