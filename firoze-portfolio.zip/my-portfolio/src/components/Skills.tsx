"use client";

import { motion } from "framer-motion";
import { Database, BarChart3, Settings2, LineChart } from "lucide-react";

const skillCategories = [
  {
    title: "Analytics & Programming",
    icon: <BarChart3 className="w-6 h-6 text-primary" />,
    skills: ["Python", "R", "SQL", "Excel (Advanced)", "Power BI", "Looker Studio", "Demand Forecasting", "Stochastic Modeling"]
  },
  {
    title: "Supply Chain & Logistics",
    icon: <LineChart className="w-6 h-6 text-primary" />,
    skills: ["Inventory Analysis", "EOQ", "S&OP", "Lead Time Management", "KPI Analysis", "Warehouse Operations", "SAP (Basics)"]
  },
  {
    title: "Tools & Engineering",
    icon: <Database className="w-6 h-6 text-primary" />,
    skills: ["AutoCAD", "SolidWorks", "Material Handling", "Microsoft Office", "Google Analytics"]
  },
  {
    title: "Continuous Improvement",
    icon: <Settings2 className="w-6 h-6 text-primary" />,
    skills: ["Lean Manufacturing", "Six Sigma Yellow Belt", "Process Optimization", "Resource Allocation"]
  }
];

export default function Skills() {
  return (
    <section id="skills" className="py-24 bg-card/30 border-y border-border/50">
      <div className="container px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 text-center"
        >
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Core Competencies</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Combining analytical rigor with supply chain expertise to deliver data-driven operational improvements.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {skillCategories.map((category, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="p-8 rounded-2xl bg-background border border-border/50 shadow-sm hover:shadow-md transition-shadow hover:border-primary/20"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 rounded-lg bg-primary/10">
                  {category.icon}
                </div>
                <h3 className="text-xl font-semibold">{category.title}</h3>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill, i) => (
                  <span 
                    key={i} 
                    className="px-3 py-1.5 rounded-md bg-secondary/60 text-secondary-foreground text-sm font-medium hover:bg-primary/10 hover:text-primary transition-colors cursor-default"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
