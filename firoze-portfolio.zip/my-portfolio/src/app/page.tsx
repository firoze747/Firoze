import Hero from "@/components/Hero";
import Experience from "@/components/Experience";
import Skills from "@/components/Skills";
import EducationProjects from "@/components/EducationProjects";

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Hero />
      <Experience />
      <Skills />
      <EducationProjects />
      
      {/* Footer */}
      <footer id="contact" className="bg-card/50 border-t border-border py-12 text-center">
        <div className="container px-4">
          <h2 className="text-2xl font-bold mb-6">Let's Connect</h2>
          <div className="flex flex-col sm:flex-row justify-center gap-6 mb-8 text-muted-foreground">
            <a href="mailto:firoze747@gmail.com" className="hover:text-primary transition-colors">
              firoze747@gmail.com
            </a>
            <span className="hidden sm:inline">•</span>
            <span>(703) 910-0211</span>
            <span className="hidden sm:inline">•</span>
            <a href="https://www.linkedin.com/in/firoze747" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">
              LinkedIn
            </a>
          </div>
          <p className="text-sm text-muted-foreground/60 focus:outline-none">
            © {new Date().getFullYear()} Md Firoze Mehedi. Designed with Next.js & Tailwind.
          </p>
        </div>
      </footer>
    </main>
  );
}
